import re, sys
from pathlib import Path

for log in sorted(Path(sys.argv[1]).glob("*_ping.log")):
    text = log.read_text()
    seqs = {int(m) for m in re.findall(r"icmp_seq=(\d+)", text)}
    tx = re.search(r"(\d+) packets transmitted", text)
    if not tx:
        print(f"{log.name}: no summary"); continue
    tx = int(tx.group(1))
    missing = sorted(set(range(1, tx + 1)) - seqs)
    where = ["LAST (stop artifact)" if s == tx else f"mid-run (real drop) seq {s}" for s in missing]
    print(f"{log.name}: tx={tx} rx={len(seqs)} missing={where or 'none'}")
