# Phase 5 supplementary runs (2026-10-31)

The parent folder is the untouched `bench_dataplane.sh PHASE=5` gate run on 5c4ff39. Its
`summary.txt` says `PHASE 5 GATES: FAIL` because of one M8 row; the evidence below decides it.
These runs were standalone (governor not pinned), which does not affect ping loss or RSS.

## M8 rust data plane + python handshake

The gate run read 67.6 kB per session (gate 64). Three gate-path re-runs on the same commit
(`m8/`, `sudo eval/measure_memory.py --clients 50 --data-plane rust --handshake python`):
60.9, 61.0, 61.2 kB, all 50/50. The pre-fix run read 61.3 kB and the unprivileged `--dev` probe
61.4-61.8 kB, so 67.6 kB was a single-snapshot outlier. Met.

## M6 epoch-switch loss and its fix

- `prefix-3ebe643-summary.txt`: the first gate run, before the fix. M6 rehandshake lost one ping
  on python-python and rust-python.
- `m6-before-fix/`: re-runs on 3ebe643. `m6-*.csv` are plain re-runs; `seq-*` were run with
  `m6-keeplogs.sh` (eval/run_rehandshake_net.sh writing its ping logs to KEEP_DIR) and checked
  with `seqcheck.py`. `seqcheck.txt` shows 5 phases with mid-run icmp_seq gaps, on rust-rust as
  well as rust-python. In rust-rust run 1 the gaps (454, 2729 = 6 x 455 pings) line up with the
  5 s rekey interval.
- Root cause: a hard one-sided epoch cutover. The server switched send and receive inside
  `respond_*`, the client only after the TCP response, and each side accepted only its current
  epoch. Shared by both data planes; no packet was ever accepted under the wrong key.
- Fix 91d4928: one previous-epoch receive state for a 5 s grace (with its own replay window),
  and the responder keeps sealing at the old epoch until an authenticated new-epoch frame or 2 s.
- `m6-after-fix/`: 3 setups x 3 runs on 5c4ff39, 0 missing icmp_seq in all 18 phases.
